(function add(num,num2){
  return num + num2;
})();
